Angry Birds em Python
========
[Youtube Video] (https://www.youtube.com/watch?v=B7G5JtCFepE&feature=youtu.be)

![Alt text](/resources/images/angry-birds-image.png?raw=true "angry-birds")

Requisitos: Python 2 ou 3 + Pygame

####Para jogar
1. Faça download do projeto ou clone-o.
3. Abra a pasta src
4. Execute o main.py

####Gravidade Zero
![Alt text](/resources/images/gravity-zero.png?raw=true "angry-birds")
* Para ativar a "gravidade zero" aperte a tecla s.
* Para voltar ao modo normal aperte a tecla n.

####Ativar e Desativar Parede 
![Alt text](/resources/images/walls.png?raw=true "angry-birds")
* Para ativar ou desativar a parede aperte a tecla w.

####Junte-se ao projeto
O projeto é Open Source, contribua a vontade.

####Para contribuir
Envie a sua branch para a develop branch
